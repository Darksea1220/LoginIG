import igdata from "../../igdata.js";
import MyPost, {Attribute} from "../Poust/Post.js";
class MyPostContainer extends HTMLElement{
    post:MyPost[]=[];
    constructor(){
        super();
        this.attachShadow({mode: "open"});
        igdata.forEach((p)=>{
            const postCard = this.ownerDocument.createElement("my-post") as MyPost;
            postCard.setAttribute(Attribute.profileimg, p.profileimg);
            postCard.setAttribute(Attribute.name, p.name);
            postCard.setAttribute(Attribute.ubication, p.ubication);
            postCard.setAttribute(Attribute.post, p.post);
            postCard.setAttribute(Attribute.views, p.views);
            postCard.setAttribute(Attribute.description, p.description);
            this.post.push(postCard);
        });
    }
    connectedCallback(){
        this.render();
    }
    render(){
        if(this.shadowRoot){
            this.shadowRoot.innerHTML = "";
            this.post.forEach((post)=>{
                this.shadowRoot?.appendChild(post);
            });
        }
    }

}
customElements.define("my-postcont", MyPostContainer);
export default MyPostContainer;